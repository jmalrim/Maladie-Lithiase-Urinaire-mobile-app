class Analyse2 {
  final String taille;
  final String surface;
  final String couleur;
  final String section;
  final String couchesExternes;
  final String noyau;
  final String surfaceInfrarouge;
  final String sectionInfrarouge;
  final String couchesExternesInfrarouge;
  final String noyauInfrarouge;
  final String typeCalcul;

  Analyse2({
    required this.taille,
    required this.surface,
    required this.couleur,
    required this.section,
    required this.couchesExternes,
    required this.noyau,
    required this.surfaceInfrarouge,
    required this.sectionInfrarouge,
    required this.couchesExternesInfrarouge,
    required this.noyauInfrarouge,
    required this.typeCalcul,
  });

  Map<String, dynamic> toMap() {
    return {
      'taille': taille,
      'surface': surface,
      'couleur': couleur,
      'section': section,
      'couchesExternes': couchesExternes,
      'noyau': noyau,
      'surfaceInfrarouge': surfaceInfrarouge,
      'sectionInfrarouge': sectionInfrarouge,
      'couchesExternesInfrarouge': couchesExternesInfrarouge,
      'noyauInfrarouge': noyauInfrarouge,
      'typeCalcul': typeCalcul,
    };
  }
}
