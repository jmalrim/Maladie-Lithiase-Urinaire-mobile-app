
class AnatomicalAnomaly {
  String? selectedAnomaly;

  AnatomicalAnomaly({this.selectedAnomaly});

  Map<String, dynamic> toJson() {
    return {
      'selectedAnomaly': selectedAnomaly,
    };
  }
}
