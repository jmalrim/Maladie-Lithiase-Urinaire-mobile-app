import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

class UserModel {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseDatabase _database = FirebaseDatabase.instance;

  Future<String> fetchFullName() async {
    User? user = _auth.currentUser;
    if (user != null) {
      DatabaseReference userRef = _database.ref().child('doctors').child(user.uid);
      DataSnapshot snapshot = await userRef.get();
      if (snapshot.exists) {
        return snapshot.child('fullName').value as String? ?? 'Unknown';
      }
    }
    return 'Unknown';
  }
}