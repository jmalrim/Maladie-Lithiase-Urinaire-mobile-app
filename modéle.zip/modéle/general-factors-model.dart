
class GeneralFactors {
  String? familyHistoryOfLithiasis;
  String? personalHistoryOfLithiasis;
  String? frequentUrinaryInfections;
  String? uniqueKidney;
  String? kidneyType;
  String? chronicRenalFailure;
  String? lastEpisodeDay;
  String? lastEpisodeMonth;
  String? lastEpisodeYear;
  String? lithiasisType;
  String? clearance;

  GeneralFactors({
    this.familyHistoryOfLithiasis,
    this.personalHistoryOfLithiasis,
    this.frequentUrinaryInfections,
    this.uniqueKidney,
    this.kidneyType,
    this.chronicRenalFailure,
    this.lastEpisodeDay,
    this.lastEpisodeMonth,
    this.lastEpisodeYear,
    this.lithiasisType,
    this.clearance,
  });

  Map<String, dynamic> toJson() {
    return {
      'familyHistoryOfLithiasis': familyHistoryOfLithiasis,
      'personalHistoryOfLithiasis': personalHistoryOfLithiasis,
      'frequentUrinaryInfections': frequentUrinaryInfections,
      'uniqueKidney': uniqueKidney,
      'kidneyType': kidneyType,
      'chronicRenalFailure': chronicRenalFailure,
      'lastEpisodeDay': lastEpisodeDay,
      'lastEpisodeMonth': lastEpisodeMonth,
      'lastEpisodeYear': lastEpisodeYear,
      'lithiasisType': lithiasisType,
      'clearance': clearance,
    };
  }
}
