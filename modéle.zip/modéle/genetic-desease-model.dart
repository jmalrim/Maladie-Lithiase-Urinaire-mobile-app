
class GeneticDisease {
  String? selectedDisease;

  GeneticDisease({this.selectedDisease});

  Map<String, dynamic> toJson() {
    return {
      'selectedDisease': selectedDisease,
    };
  }
}
