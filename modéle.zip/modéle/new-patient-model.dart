// models/patient_model.dart

class Patient {
  String name;
  DateTime dateOfBirth;
  String gender;
  double height;
  double weight;
  String address;
  String email;
  String phone;
  String recordNumber;

  Patient({
    required this.name,
    required this.dateOfBirth,
    required this.gender,
    required this.height,
    required this.weight,
    required this.address,
    required this.email,
    required this.phone,
    required this.recordNumber,
  });

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'dateOfBirth': {
        'day': dateOfBirth.day,
        'month': dateOfBirth.month,
        'year': dateOfBirth.year,
      },
      'gender': gender,
      'height': height,
      'weight': weight,
      'address': address,
      'email': email,
      'phone': phone,
      'recordNumber': recordNumber,
    };
  }
}
