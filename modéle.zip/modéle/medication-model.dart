
class Medication {
  String? selectedOption;
  String? medicationName;

  Medication({this.selectedOption, this.medicationName});

  Map<String, dynamic> toJson() {
    return {
      'selectedOption': selectedOption,
      'medicationName': medicationName,
    };
  }
}
