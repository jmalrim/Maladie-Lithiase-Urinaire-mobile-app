// modéle/calcul-modéle.dart

class Calcul {
  String? taille;
  String? localisation;
  String? lateralite;
  String? caracteristiques;
  String? modeEvacuation;
  String? imageUrl;

  Calcul({
    this.taille,
    this.localisation,
    this.lateralite,
    this.caracteristiques,
    this.modeEvacuation,
    this.imageUrl,
  });

  Map<String, dynamic> toJson() {
    return {
      'taille': taille,
      'localisation': localisation,
      'lateralite': lateralite,
      'caracteristiques': caracteristiques,
      'modeEvacuation': modeEvacuation,
      'imageUrl': imageUrl,
    };
  }
}
