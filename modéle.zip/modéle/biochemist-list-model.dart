class PatientSummary {
  final String id;
  final String fullName;
  final String recordNumber;

  PatientSummary({required this.id, required this.fullName, required this.recordNumber});

  factory PatientSummary.fromMap(String id, Map<String, dynamic> data) {
    return PatientSummary(
      id: id,
      fullName: data['name'] ?? '',
      recordNumber: data['recordNumber'] ?? '',
    );
  }
}
