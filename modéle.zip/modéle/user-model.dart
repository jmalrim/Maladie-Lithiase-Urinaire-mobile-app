
class UserModel {
  String email;
  String password;

  UserModel({required this.email, required this.password});
}
// models/user_model.dart
class UserUp {
  String fullName;
  String email;
  String password;
  String role;

  UserUp({required this.fullName, required this.email, required this.password, required this.role});
}

