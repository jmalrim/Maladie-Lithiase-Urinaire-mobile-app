class Patient {
  String fullName;
  String recordNumber;
  String address;
  String gender;
  Map<String, dynamic> anatomicalAnomalies;
  Map<String, Map<String, dynamic>> calculs;
  int weight;
  Map<String, int> dateOfBirth;
  Map<String, Map<String, dynamic>> drainages;
  Map<String, String> medication;
  Map<String, String> geneticDiseases;
  String phone;
  Map<String, dynamic> associatedDiseases;
  String email;
  Map<String, dynamic> generalFactors;
  int height;

  Patient({
    required this.fullName,
    required this.recordNumber,
    required this.address,
    required this.gender,
    required this.anatomicalAnomalies,
    required this.calculs,
    required this.weight,
    required this.dateOfBirth,
    required this.drainages,
    required this.medication,
    required this.geneticDiseases,
    required this.phone,
    required this.associatedDiseases,
    required this.email,
    required this.generalFactors,
    required this.height,
  });

  factory Patient.fromMap(Map<String, dynamic> data) {
    return Patient(
      fullName: data['name'] ?? '',
      recordNumber: data['recordNumber'] ?? '',
      address: data['address'] ?? '',
      gender: data['gender'] ?? '',
      anatomicalAnomalies: Map<String, dynamic>.from(data['anatomicalAnomalies'] ?? {}),
      calculs: (data['calculs'] as Map<String, dynamic>? ?? {}).map<String, Map<String, dynamic>>(
            (key, value) => MapEntry(key, Map<String, dynamic>.from(value)),
      ),
      weight: data['weight'] ?? 0,
      dateOfBirth: Map<String, int>.from(data['dateOfBirth'] ?? {}),
      drainages: (data['drainages'] as Map<String, dynamic>? ?? {}).map<String, Map<String, dynamic>>(
            (key, value) => MapEntry(key, Map<String, dynamic>.from(value)),
      ),
      medication: Map<String, String>.from(data['medication'] ?? {}),
      geneticDiseases: Map<String, String>.from(data['geneticDiseases'] ?? {}),
      phone: data['phone'] ?? '',
      associatedDiseases: Map<String, dynamic>.from(data['associatedDiseases'] ?? {}),
      email: data['email'] ?? '',
      generalFactors: Map<String, dynamic>.from(data['generalFactors'] ?? {}),
      height: data['height'] ?? 0,
    );
  }
}
