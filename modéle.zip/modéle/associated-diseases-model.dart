
class AssociatedDiseases {
  String? selection;
  List<String>? selectedDiseases;
  List<String>? selectedGastroIntestinalDiseases;
  String? otherDisease;

  AssociatedDiseases({
    this.selection,
    this.selectedDiseases,
    this.selectedGastroIntestinalDiseases,
    this.otherDisease,
  });

  Map<String, dynamic> toJson() {
    return {
      'selection': selection,
      'selectedDiseases': selectedDiseases,
      'selectedGastroIntestinalDiseases': selectedGastroIntestinalDiseases,
      'otherDisease': otherDisease,
    };
  }
}
