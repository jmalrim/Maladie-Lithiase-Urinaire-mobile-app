// modéle/drainage-modéle.dart

class Drainage {
  String? drainageMode;
  String? side;
  DateTime? drainageDate;
  DateTime? removalDate;
  String? jjTubeType;

  Drainage({
    this.drainageMode,
    this.side,
    this.drainageDate,
    this.removalDate,
    this.jjTubeType,
  });

  Map<String, dynamic> toJson() {
    return {
      'drainageMode': drainageMode,
      'side': side,
      'drainageDate': drainageDate?.toIso8601String(),
      'removalDate': removalDate?.toIso8601String(),
      'jjTubeType': jjTubeType,
    };
  }
}
