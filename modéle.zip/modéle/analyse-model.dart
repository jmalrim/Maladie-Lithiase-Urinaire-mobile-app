class Patient {
  final String fullName;
  final String recordNumber;
  final String? imageUrl;

  Patient({
    required this.fullName,
    required this.recordNumber,
    this.imageUrl,
  });

  factory Patient.fromMap(Map<String, dynamic> data, String? imageUrl) {
    return Patient(
      fullName: data['name'] ?? '',
      recordNumber: data['recordNumber'] ?? '',
      imageUrl: imageUrl,
    );
  }
}
