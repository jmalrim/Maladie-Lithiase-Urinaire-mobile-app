// vues/general_factors-vue.dart

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fatouma/controlleurs/general-factors-controller.dart';
import 'package:fatouma/modéle/general-factors-model.dart';

class GeneralFactorsPage extends StatefulWidget {
  final String patientId;

  const GeneralFactorsPage({Key? key, required this.patientId}) : super(key: key);

  @override
  _GeneralFactorsPageState createState() => _GeneralFactorsPageState();
}

class _GeneralFactorsPageState extends State<GeneralFactorsPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GeneralFactorsController _controller = GeneralFactorsController();
  final _formKey = GlobalKey<FormState>();

  String? _familyHistoryOfLithiasis;
  String? _personalHistoryOfLithiasis;
  String? _frequentUrinaryInfections;
  String? _uniqueKidney;
  String? _kidneyType;
  String? _chronicRenalFailure;

  final TextEditingController _lastEpisodeDayController = TextEditingController();
  final TextEditingController _lastEpisodeMonthController = TextEditingController();
  final TextEditingController _lastEpisodeYearController = TextEditingController();
  final TextEditingController _clearanceController = TextEditingController();

  String? _lithiasisType;
  final List<String> _lithiasisTypes = ['Type 1', 'Type 2', 'Type 3'];

  bool _showLastEpisodeFields = false;
  bool _showLithiasisTypeField = false;
  bool _showKidneyTypeField = false;
  bool _showClearanceField = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Facteurs Généraux'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildRadioField(
                title: 'Antécédents familiaux de lithiases',
                value: _familyHistoryOfLithiasis,
                onChanged: (value) {
                  setState(() {
                    _familyHistoryOfLithiasis = value;
                  });
                },
              ),
              const SizedBox(height: 20.0),
              _buildRadioField(
                title: 'Antécédents personnels de lithiases',
                value: _personalHistoryOfLithiasis,
                onChanged: (value) {
                  setState(() {
                    _personalHistoryOfLithiasis = value;
                    _showLastEpisodeFields = value == 'Oui';
                  });
                },
              ),
              if (_showLastEpisodeFields) ...[
                const SizedBox(height: 20.0),
                _buildLastEpisodeField(),
                const SizedBox(height: 20.0),
                _buildLithiasisTypeField(),
              ],
              const SizedBox(height: 20.0),
              _buildRadioField(
                title: 'Antécédents d\'infections urinaires fréquentes',
                value: _frequentUrinaryInfections,
                onChanged: (value) {
                  setState(() {
                    _frequentUrinaryInfections = value;
                  });
                },
              ),
              const SizedBox(height: 20.0),
              _buildRadioField(
                title: 'Rein unique',
                value: _uniqueKidney,
                onChanged: (value) {
                  setState(() {
                    _uniqueKidney = value;
                    _showKidneyTypeField = value == 'Oui';
                  });
                },
              ),
              if (_showKidneyTypeField) ...[
                const SizedBox(height: 20.0),
                _buildKidneyTypeField(),
              ],
              const SizedBox(height: 20.0),
              _buildRadioField(
                title: 'Insuffisance rénale chronique',
                value: _chronicRenalFailure,
                onChanged: (value) {
                  setState(() {
                    _chronicRenalFailure = value;
                    _showClearanceField = value == 'Oui';
                  });
                },
              ),
              if (_showClearanceField) ...[
                const SizedBox(height: 20.0),
                _buildClearanceField(),
              ],
              const SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: _saveDataAndNavigate,
                child: const Text('Next'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRadioField({required String title, required String? value, required ValueChanged<String?> onChanged}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        Row(
          children: [
            Radio<String>(
              value: 'Oui',
              groupValue: value,
              onChanged: onChanged,
            ),
            const Text('Oui'),
            Radio<String>(
              value: 'Non',
              groupValue: value,
              onChanged: onChanged,
            ),
            const Text('Non'),
          ],
        ),
      ],
    );
  }

  Widget _buildLastEpisodeField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Dernier épisode',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10.0),
        Row(
          children: [
            Expanded(
              child: TextFormField(
                controller: _lastEpisodeDayController,
                decoration: const InputDecoration(hintText: 'Jour', border: OutlineInputBorder()),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Veuillez entrer le jour';
                  }
                  return null;
                },
              ),
            ),
            const SizedBox(width: 10.0),
            Expanded(
              child: TextFormField(
                controller: _lastEpisodeMonthController,
                decoration: const InputDecoration(hintText: 'Mois', border: OutlineInputBorder()),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Veuillez entrer le mois';
                  }
                  return null;
                },
              ),
            ),
            const SizedBox(width: 10.0),
            Expanded(
              child: TextFormField(
                controller: _lastEpisodeYearController,
                decoration: const InputDecoration(hintText: 'Année', border: OutlineInputBorder()),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Veuillez entrer l\'année';
                  }
                  return null;
                },
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildLithiasisTypeField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Type de lithiases',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10.0),
        DropdownButtonFormField<String>(
          value: _lithiasisType,
          hint: const Text('Sélectionnez le type de lithiases'),
          items: _lithiasisTypes.map((String value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Text(value),
            );
          }).toList(),
          onChanged: (newValue) {
            setState(() {
              _lithiasisType = newValue;
            });
          },
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Veuillez sélectionner un type de lithiases';
            }
            return null;
          },
        ),
      ],
    );
  }

  Widget _buildKidneyTypeField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Type de rein unique',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        Row(
          children: [
            Radio<String>(
              value: 'Anatomique',
              groupValue: _kidneyType,
              onChanged: (value) {
                setState(() {
                  _kidneyType = value;
                });
              },
            ),
            const Text('Anatomique'),
            Radio<String>(
              value: 'Fonctionnel',
              groupValue: _kidneyType,
              onChanged: (value) {
                setState(() {
                  _kidneyType = value;
                });
              },
            ),
            const Text('Fonctionnel'),
          ],
        ),
      ],
    );
  }

  Widget _buildClearanceField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Clairance (ml/min/1.73m²)',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10.0),
        TextFormField(
          controller: _clearanceController,
          decoration: const InputDecoration(
            hintText: 'Clairance',
            border: OutlineInputBorder(),
          ),
          keyboardType: TextInputType.number,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Veuillez entrer la clairance';
            }
            return null;
          },
        ),
      ],
    );
  }

  void _saveDataAndNavigate() async {
    if (!_formKey.currentState!.validate()) return;

    GeneralFactors generalFactors = GeneralFactors(
      familyHistoryOfLithiasis: _familyHistoryOfLithiasis,
      personalHistoryOfLithiasis: _personalHistoryOfLithiasis,
      frequentUrinaryInfections: _frequentUrinaryInfections,
      uniqueKidney: _uniqueKidney,
      kidneyType: _kidneyType,
      chronicRenalFailure: _chronicRenalFailure,
      lastEpisodeDay: _lastEpisodeDayController.text,
      lastEpisodeMonth: _lastEpisodeMonthController.text,
      lastEpisodeYear: _lastEpisodeYearController.text,
      lithiasisType: _lithiasisType,
      clearance: _clearanceController.text,
    );

    await _controller.saveGeneralFactors(widget.patientId, generalFactors, context);

    Navigator.pushNamed(
      context,
      '/genetic_diseases',
      arguments: widget.patientId,
    );
  }
}
