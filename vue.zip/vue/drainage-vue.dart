// vues/drainage-vue.dart

import 'package:flutter/material.dart';
import 'package:fatouma/controlleurs/drainage-controller.dart';
import 'package:fatouma/modéle/drainage-model.dart';

import '../modéle/drainage-model.dart';

class DrainagePage extends StatefulWidget {
  final String patientId;

  const DrainagePage({Key? key, required this.patientId}) : super(key: key);

  @override
  _DrainagePageState createState() => _DrainagePageState();
}

class _DrainagePageState extends State<DrainagePage> {
  String? _drainageMode;
  String? _side;
  DateTime? _drainageDate;
  DateTime? _removalDate;
  String? _jjTubeType;
  final DrainageController _controller = DrainageController();

  Future<void> _selectDate(BuildContext context, DateTime? initialDate, Function(DateTime) onDateSelected) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: initialDate ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != initialDate) {
      onDateSelected(picked);
    }
  }

  void _saveDrainage() async {
    Drainage drainage = Drainage(
      drainageMode: _drainageMode,
      side: _side,
      drainageDate: _drainageDate,
      removalDate: _removalDate,
      jjTubeType: _jjTubeType,
    );

    await _controller.saveDrainage(widget.patientId, drainage, context);
    Navigator.pushNamed(
      context,
      '/patientdetail',
      arguments: widget.patientId,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Drainage'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Mode du drainage des voies excrétrices :',
              style: TextStyle(fontSize: 16),
            ),
            ListTile(
              title: const Text('Sonde JJ'),
              leading: Radio<String>(
                value: 'Sonde JJ',
                groupValue: _drainageMode,
                onChanged: (String? value) {
                  setState(() {
                    _drainageMode = value;
                  });
                },
              ),
            ),
            ListTile(
              title: const Text('Sonde urétérale'),
              leading: Radio<String>(
                value: 'Sonde urétérale',
                groupValue: _drainageMode,
                onChanged: (String? value) {
                  setState(() {
                    _drainageMode = value;
                  });
                },
              ),
            ),
            ListTile(
              title: const Text('Sonde de néphrostomie'),
              leading: Radio<String>(
                value: 'Sonde de néphrostomie',
                groupValue: _drainageMode,
                onChanged: (String? value) {
                  setState(() {
                    _drainageMode = value;
                  });
                },
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Côté :',
              style: TextStyle(fontSize: 16),
            ),
            Row(
              children: <Widget>[
                Expanded(
                  child: RadioListTile<String>(
                    title: const Text('D'),
                    value: 'D',
                    groupValue: _side,
                    onChanged: (String? value) {
                      setState(() {
                        _side = value;
                      });
                    },
                  ),
                ),
                Expanded(
                  child: RadioListTile<String>(
                    title: const Text('O'),
                    value: 'O',
                    groupValue: _side,
                    onChanged: (String? value) {
                      setState(() {
                        _side = value;
                      });
                    },
                  ),
                ),
              ],
            ),
            Row(
              children: <Widget>[
                Expanded(
                  child: RadioListTile<String>(
                    title: const Text('G'),
                    value: 'G',
                    groupValue: _side,
                    onChanged: (String? value) {
                      setState(() {
                        _side = value;
                      });
                    },
                  ),
                ),
                Expanded(
                  child: RadioListTile<String>(
                    title: const Text('Bilatéral'),
                    value: 'Bilatéral',
                    groupValue: _side,
                    onChanged: (String? value) {
                      setState(() {
                        _side = value;
                      });
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                const Text('Date du drainage :', style: TextStyle(fontSize: 16)),
                IconButton(
                  icon: const Icon(Icons.calendar_today),
                  onPressed: () => _selectDate(context, _drainageDate, (date) {
                    setState(() {
                      _drainageDate = date;
                    });
                  }),
                ),
                Text(_drainageDate == null ? ' / / ' : '${_drainageDate!.day}/${_drainageDate!.month}/${_drainageDate!.year}'),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                const Text('Type de sonde JJ :', style: TextStyle(fontSize: 16)),
                const SizedBox(width: 16),
                Expanded(
                  child: TextField(
                    onChanged: (value) {
                      setState(() {
                        _jjTubeType = value;
                      });
                    },
                    decoration: const InputDecoration(
                      hintText: 'Entrez le type de sonde JJ',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                const Text('Date de retrait :', style: TextStyle(fontSize: 16)),
                IconButton(
                  icon: const Icon(Icons.calendar_today),
                  onPressed: () => _selectDate(context, _removalDate, (date) {
                    setState(() {
                      _removalDate = date;
                    });
                  }),
                ),
                Text(_removalDate == null ? ' / / ' : '${_removalDate!.day}/${_removalDate!.month}/${_removalDate!.year}'),
              ],
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _saveDrainage,
              child: const Text('Valider'),
            ),
          ],
        ),
      ),
    );
  }
}
