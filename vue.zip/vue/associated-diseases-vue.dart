
import 'package:flutter/material.dart';
import 'package:fatouma/controlleurs/associated-diseases-controller.dart';
import 'package:fatouma/modéle/associated-diseases-model.dart';


class AssociatedDiseasesPage extends StatefulWidget {
  final String patientId;

  const AssociatedDiseasesPage({Key? key, required this.patientId}) : super(key: key);

  @override
  _AssociatedDiseasesPageState createState() => _AssociatedDiseasesPageState();
}

class _AssociatedDiseasesPageState extends State<AssociatedDiseasesPage> {
  final AssociatedDiseasesController _controller = AssociatedDiseasesController();
  List<String> _selectedDiseases = [];
  List<String> _subDiseases = [
    'Bypass Jéjuno-Iléal',
    'Résection Intestinale',
    'Maladie de Crohn',
    'Syndrome de Malabsorption',
    'Hyperoxalurie Entrérique',
    'Insuffisance Pancréatique Exocrine',
    'Chirurgie Bariatrique',
  ];
  List<String> _selectedGastroIntestinalDiseases = [];
  String? _radioSelection;
  String? _otherDisease;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Maladies Associées'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Y a-t-il des maladies associées ?',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            ListTile(
              title: const Text('Oui'),
              leading: Radio<String>(
                value: 'Oui',
                groupValue: _radioSelection,
                onChanged: (String? value) {
                  setState(() {
                    _radioSelection = value;
                  });
                },
              ),
            ),
            ListTile(
              title: const Text('Non'),
              leading: Radio<String>(
                value: 'Non',
                groupValue: _radioSelection,
                onChanged: (String? value) {
                  setState(() {
                    _radioSelection = value;
                  });
                },
              ),
            ),
            ListTile(
              title: const Text('Autre'),
              leading: Radio<String>(
                value: 'Autre',
                groupValue: _radioSelection,
                onChanged: (String? value) {
                  setState(() {
                    _radioSelection = value;
                  });
                },
              ),
            ),
            if (_radioSelection == 'Oui') ...[
              const SizedBox(height: 10.0),
              const Text(
                'Choisissez les maladies associées :',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10.0),
              _buildDiseaseCheckbox('Hyperparathyroidie'),
              _buildDiseaseCheckbox('Syndrome Métabolique'),
              _buildDiseaseCheckbox('Trouble Minéral Osseux'),
              _buildDiseaseCheckbox('Néphrocalcinose'),
              _buildDiseaseCheckbox('Polykystose Rénale'),
              _buildDiseaseCheckbox('Affections Gastro-intestinales et Chirurgie Bariatrique'),
              _buildDiseaseCheckbox('Hypovitaminose D'),
              _buildDiseaseCheckbox('Sarcoidose'),
              _buildDiseaseCheckbox('Vessie Neurologique ou Lésions de la Moelle Spinale'),
              if (_selectedDiseases.contains('Affections Gastro-intestinales et Chirurgie Bariatrique')) ...[
                const SizedBox(height: 10.0),
                const Text(
                  'Sous-maladies pour Affections Gastro-intestinales et Chirurgie Bariatrique :',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                for (var subDisease in _subDiseases) ...[
                  SizedBox(height: 5.0),
                  Row(
                    children: [
                      Checkbox(
                        value: _selectedGastroIntestinalDiseases.contains(subDisease),
                        onChanged: (value) {
                          setState(() {
                            if (value != null && value) {
                              _selectedGastroIntestinalDiseases.add(subDisease);
                            } else {
                              _selectedGastroIntestinalDiseases.remove(subDisease);
                            }
                          });
                        },
                      ),
                      Text(subDisease),
                    ],
                  ),
                ],
              ],
            ] else if (_radioSelection == 'Autre') ...[
              const SizedBox(height: 10.0),
              TextFormField(
                decoration: const InputDecoration(
                  labelText: 'Veuillez préciser',
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) {
                  setState(() {
                    _otherDisease = value;
                  });
                },
              ),
              const SizedBox(height: 20.0),
            ],
            const SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: _saveAssociatedDiseasesAndNavigate,
              child: const Text('Next'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDiseaseCheckbox(String diseaseName) {
    return Row(
      children: [
        Checkbox(
          value: _selectedDiseases.contains(diseaseName),
          onChanged: (value) {
            setState(() {
              if (value != null && value) {
                _selectedDiseases.add(diseaseName);
              } else {
                _selectedDiseases.remove(diseaseName);
                if (diseaseName == 'Affections Gastro-intestinales et Chirurgie Bariatrique') {
                  _selectedGastroIntestinalDiseases.clear();
                }
              }
            });
          },
        ),
        Text(diseaseName),
      ],
    );
  }

  void _saveAssociatedDiseasesAndNavigate() async {
    if (_radioSelection == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Veuillez sélectionner une option')),
      );
      return;
    }

    AssociatedDiseases diseases = AssociatedDiseases(
      selection: _radioSelection,
      selectedDiseases: _selectedDiseases,
      selectedGastroIntestinalDiseases: _selectedGastroIntestinalDiseases,
      otherDisease: _radioSelection == 'Autre' ? _otherDisease : null,
    );

    await _controller.saveAssociatedDiseases(widget.patientId, diseases, context);

    Navigator.pushNamed(
      context,
      '/general_factors',
      arguments: widget.patientId,
    );
  }
}
