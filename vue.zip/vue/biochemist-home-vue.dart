
import 'package:flutter/material.dart';
import '../controlleurs/biochemist-home-controller.dart';

class HomeBio extends StatefulWidget {
  const HomeBio({Key? key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<HomeBio> {
  final HomeController _controller = HomeController();
  String _fullName = 'Loading...';
  String _profession = 'Loading...';

  @override
  void initState() {
    super.initState();
    _loadDoctorInfo();
  }

  void _loadDoctorInfo() async {
    String fullName = await _controller.getFullName();
    String profession = await _controller.getProfession();
    setState(() {
      _fullName = fullName;
      _profession = profession;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('LithoApp'),
        automaticallyImplyLeading: false,
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              _controller.handleMenuAction(value, context);
            },
            itemBuilder: (BuildContext context) {
              return [
                const PopupMenuItem<String>(
                  value: 'patient_list',
                  child: Text('Liste des patients'),
                ),
              ];
            },
          ),
        ],
      ),
      body: Container(
        color: Colors.blue,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Bienvenue',
                style: TextStyle(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'Dr $_fullName',
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                _profession,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushNamed(
                      context,
                      '/biochemist-list'
                  );
                },
                child: const Text('Liste des patients'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black12,
                  padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                  textStyle: const TextStyle(fontSize: 26),
                ),
              ),
              
            ],
          ),
        ),
      ),
    );
  }
}
