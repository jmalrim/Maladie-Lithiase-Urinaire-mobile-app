import 'package:flutter/material.dart';
import 'package:barcode_widget/barcode_widget.dart';
import 'package:fatouma/controlleurs/analyse-controller.dart';
import 'package:fatouma/modéle/analyse-model.dart';

class AnalysePage extends StatefulWidget {
  final String patientId;

  const AnalysePage({Key? key, required this.patientId}) : super(key: key);

  @override
  _AnalysePageState createState() => _AnalysePageState();
}

class _AnalysePageState extends State<AnalysePage> {
  final AnalyseController _controller = AnalyseController();
  Patient? patientData;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchPatientData();
  }

  Future<void> _fetchPatientData() async {
    try {
      Patient? data = await _controller.fetchPatientData(widget.patientId);
      if (mounted) {
        setState(() {
          patientData = data;
          isLoading = false;
        });
        if (patientData != null) {
          print('Patient data loaded: ${patientData!.fullName}');
        } else {
          print('Patient data is null');
        }
      }
    } catch (e) {
      print('Error in _fetchPatientData: $e');
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load patient data: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Analyse du calcul')),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : patientData == null
          ? const Center(child: Text('No data available'))
          : Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Veuillez entrer les données de l\'analyse du calcul suivant :',
                style: TextStyle(fontSize: 18),
              ),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(10.0),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${patientData!.fullName}\nAnalyse de Calcul\nDI : ${patientData!.recordNumber}',
                      style: const TextStyle(fontSize: 16),
                    ),
                    const SizedBox(height: 10),
                    BarcodeWidget(
                      barcode: Barcode.code128(),
                      data: widget.patientId,
                      width: 200,
                      height: 80,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Image opératoire :',
                style: TextStyle(fontSize: 18),
              ),
              const SizedBox(height: 10),
              // Display image if available
              patientData!.imageUrl != null
                  ? Image.network(
                patientData!.imageUrl!,
                height: 200,
                fit: BoxFit.cover,
              )
                  : Container(
                color: Colors.grey[200],
                height: 200,
                child: const Center(child: Text('No image available')),
              ),
              const SizedBox(height: 20),
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/analyse2');
                  },
                  child: const Text('Entrée des données'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
