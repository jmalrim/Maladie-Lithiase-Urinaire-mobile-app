import 'package:flutter/material.dart';
import 'package:fatouma/controlleurs/biochemist-list-controller.dart';
import 'package:fatouma/modéle/biochemist-list-model.dart';
import 'package:fatouma/vue/patient-detail-vue.dart';

class BiochemistPatientListPage extends StatefulWidget {
  @override
  _BiochemistPatientListPageState createState() => _BiochemistPatientListPageState();
}

class _BiochemistPatientListPageState extends State<BiochemistPatientListPage> {
  final BiochemistPatientsController _controller = BiochemistPatientsController();
  List<PatientSummary> patients = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchAllPatients();
  }

  Future<void> _fetchAllPatients() async {
    try {
      print('Fetching all patients...'); // Debug print
      List<PatientSummary> data = await _controller.fetchAllPatients();
      if (mounted) {
        setState(() {
          patients = data;
          isLoading = false;
        });
        print('Patients loaded: $patients'); // Debug print
      }
    } catch (e) {
      print('Error fetching patients: $e'); // Debug print
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load patients: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Liste des Patients')),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
        itemCount: patients.length,
        itemBuilder: (context, index) {
          final patient = patients[index];
          return ListTile(
            title: Text(patient.fullName),
            subtitle: Text('Record Number: ${patient.recordNumber}'),
            trailing: ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => PatientDetailPage(patientId: patient.id),
                  ),
                );
              },
              child: const Text('Consulter'),
            ),
          );
        },
      ),
    );
  }
}
