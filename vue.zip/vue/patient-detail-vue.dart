import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:fatouma/controlleurs/patient-detail-controller.dart';
import 'package:fatouma/modéle/patient-detail-model.dart';

class PatientDetailPage extends StatefulWidget {
  final String patientId;

  const PatientDetailPage({Key? key, required this.patientId}) : super(key: key);

  @override
  _PatientDetailPageState createState() => _PatientDetailPageState();
}

class _PatientDetailPageState extends State<PatientDetailPage> {
  final PatientDetailController _controller = PatientDetailController();
  Patient? patientData;
  bool isLoading = true;
  String? profession;

  @override
  void initState() {
    super.initState();
    _fetchPatientData();
    _fetchUserProfession();
  }

  Future<void> _fetchPatientData() async {
    try {
      print('Fetching patient data for ID: ${widget.patientId}');
      Patient? data = await _controller.fetchPatientData(widget.patientId);
      if (mounted) {
        setState(() {
          patientData = data;
          isLoading = false;
        });
        print('Patient data loaded: $patientData');
      }
    } catch (e) {
      print('Error in _fetchPatientData: $e');
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load patient data: $e')),
      );
    }
  }

  Future<void> _fetchUserProfession() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      DatabaseReference userRef = FirebaseDatabase.instance.ref().child('doctors/${user.uid}');
      DataSnapshot snapshot = await userRef.get();
      if (snapshot.exists) {
        setState(() {
          profession = snapshot.child('profession').value as String?;
        });
      }
    }
  }

  void _onValiderPressed() {
    if (profession == "Urologue") {
      Navigator.pushNamed(context, '/patientslist');
    } else {
      Navigator.pushNamed(context, '/biochemist-list');
    }
  }

  void _onModifierPressed() {
    Navigator.pushNamed(context, '/anatomical_anomalies',arguments: widget.patientId);
  }

  void _onDemandeBilanMetaboliquePressed() {
    // Implement the action for Demande de bilan métabolique
  }

  void _onDemandeAnalyseCalculPressed() {
    Navigator.pushNamed(context, '/analyse1',arguments: widget.patientId);
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Patient Details')),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : patientData == null
          ? const Center(child: Text('No data available'))
          : Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Full Name: ${patientData!.fullName}',
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              Text('Record Number: ${patientData!.recordNumber}'),
              const SizedBox(height: 10),
              Text('Address: ${patientData!.address}'),
              const SizedBox(height: 10),
              Text('Gender: ${patientData!.gender}'),
              const SizedBox(height: 10),
              Text('Weight: ${patientData!.weight} kg'),
              const SizedBox(height: 10),
              Text('Height: ${patientData!.height} cm'),
              const SizedBox(height: 10),
              Text('Phone: ${patientData!.phone}'),
              const SizedBox(height: 10),
              Text('Email: ${patientData!.email}'),
              const SizedBox(height: 10),
              Text('Date of Birth: ${patientData!.dateOfBirth['day']}/${patientData!.dateOfBirth['month']}/${patientData!.dateOfBirth['year']}'),
              const SizedBox(height: 10),
              Text('Anatomical Anomalies: ${patientData!.anatomicalAnomalies.toString()}'),
              const SizedBox(height: 10),
              Text('Calculs: ${patientData!.calculs.toString()}'),
              const SizedBox(height: 10),
              Text('Drainages: ${patientData!.drainages.toString()}'),
              const SizedBox(height: 10),
              Text('Medication: ${patientData!.medication.toString()}'),
              const SizedBox(height: 10),
              Text('Genetic Diseases: ${patientData!.geneticDiseases.toString()}'),
              const SizedBox(height: 10),
              Text('Associated Diseases: ${patientData!.associatedDiseases.toString()}'),
              const SizedBox(height: 10),
              Text('General Factors: ${patientData!.generalFactors.toString()}'),
              const SizedBox(height: 20),
              Center(
                child: Column(
                  children: [
                    ElevatedButton(
                      onPressed: _onValiderPressed,
                      child: const Text('Valider'),
                    ),

                    const SizedBox(height: 10),
                    ElevatedButton(
                      onPressed: _onModifierPressed,
                      child: const Text('Modifier'),
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _onDemandeBilanMetaboliquePressed,
                        child: const Text('Demande de bilan métabolique'),
                      ),
                    ),
                    const SizedBox(height: 10),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _onDemandeAnalyseCalculPressed,
                        child: const Text('Demande d\'analyse de calcul'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
