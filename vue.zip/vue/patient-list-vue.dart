import 'package:flutter/material.dart';
import 'package:fatouma/controlleurs/patient-list-controller.dart';
import 'package:fatouma/modéle/patient-list-model.dart';
import 'package:fatouma/vue/patient-detail-vue.dart';
import 'anatomical-anomalies-vue.dart';

class PatientListPage extends StatefulWidget {
  @override
  _PatientListPageState createState() => _PatientListPageState();
}

class _PatientListPageState extends State<PatientListPage> {
  final ListePatientsController _controller = ListePatientsController();
  List<PatientSummary> patients = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchPatients();
  }

  Future<void> _fetchPatients() async {
    try {
      List<PatientSummary> data = await _controller.fetchPatients();
      if (mounted) {
        setState(() {
          patients = data;
          isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load patients: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Liste des Patients')),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
        itemCount: patients.length,
        itemBuilder: (context, index) {
          final patient = patients[index];
          return ListTile(
            title: Text(patient.fullName),
            subtitle: Text('Record Number: ${patient.recordNumber}'),
            trailing: FittedBox(
              fit: BoxFit.scaleDown,
              child: Row(
                children: [
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PatientDetailPage(patientId: patient.id),
                        ),
                      );
                    },
                    child: const Text('Consulter'),
                  ),
                  SizedBox(width: 8), // Space between buttons
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => AnatomicalAnomaliesPage(patientId: patient.id),
                        ),
                      );
                    },
                    child: const Text('Modifier'),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
