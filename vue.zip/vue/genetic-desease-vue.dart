import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fatouma/controlleurs/genetic-desease-controller.dart';
import 'package:fatouma/modéle/genetic-desease-model.dart';

class GeneticDiseasesPage extends StatefulWidget {
  final String patientId;

  const GeneticDiseasesPage({Key? key, required this.patientId}) : super(key: key);

  @override
  _GeneticDiseasesPageState createState() => _GeneticDiseasesPageState();
}

class _GeneticDiseasesPageState extends State<GeneticDiseasesPage> {
  String? _radioSelection;
  String? _otherDisease;
  String? _selectedDisease;
  final GeneticDiseasesController _controller = GeneticDiseasesController();

  final List<String> _diseaseOptions = [
    'Cystinurie (A , B , AB)',
    'Hyperoxalurie primaire',
    'Acidose tubulaire type I',
    '2.8-Dihydroxyadeninurie',
    'Xanthinurie',
    'Syndrome de Lesch-Nyhan',
    'Fibrose cystique',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Maladies Génétiques'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Y a-t-il des maladies génétiques ?',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              ListTile(
                title: const Text('Oui'),
                leading: Radio<String>(
                  value: 'Oui',
                  groupValue: _radioSelection,
                  onChanged: (String? value) {
                    setState(() {
                      _radioSelection = value;
                    });
                  },
                ),
              ),
              ListTile(
                title: const Text('Non'),
                leading: Radio<String>(
                  value: 'Non',
                  groupValue: _radioSelection,
                  onChanged: (String? value) {
                    setState(() {
                      _radioSelection = value;
                    });
                  },
                ),
              ),
              ListTile(
                title: const Text('Autre'),
                leading: Radio<String>(
                  value: 'Autre',
                  groupValue: _radioSelection,
                  onChanged: (String? value) {
                    setState(() {
                      _radioSelection = value;
                    });
                  },
                ),
              ),
              if (_radioSelection == 'Oui') ...[
                const SizedBox(height: 10.0),
                const Text(
                  'Choisissez la maladie génétique :',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10.0),
                for (String option in _diseaseOptions) ...[
                  RadioListTile<String>(
                    title: Text(option),
                    value: option,
                    groupValue: _selectedDisease,
                    onChanged: (value) {
                      setState(() {
                        _selectedDisease = value;
                      });
                    },
                  ),
                ],
              ] else if (_radioSelection == 'Autre') ...[
                const SizedBox(height: 20.0),
                TextFormField(
                  decoration: const InputDecoration(
                    labelText: 'Veuillez préciser',
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (value) {
                    setState(() {
                      _otherDisease = value;
                    });
                  },
                ),
              ],
              const SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: _saveDataAndNavigate,
                child: const Text('Next'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _saveDataAndNavigate() async {
    if (_selectedDisease == null && _otherDisease == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Veuillez sélectionner ou préciser une maladie')),
      );
      return;
    }

    GeneticDisease geneticDisease = GeneticDisease(
      selectedDisease: _radioSelection == 'Autre' ? _otherDisease : _selectedDisease,
    );

    await _controller.saveGeneticDisease(widget.patientId, geneticDisease, context);

    Navigator.pushNamed(
      context,
      '/medications',
      arguments: widget.patientId,
    );
  }
}
