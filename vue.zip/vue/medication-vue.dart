// vues/medication-vue.dart

import 'package:flutter/material.dart';
import 'package:fatouma/controlleurs/medication-controller.dart';
import 'package:fatouma/modéle/medication-model.dart';

class MedicationPage extends StatefulWidget {
  final String patientId;

  const MedicationPage({Key? key, required this.patientId}) : super(key: key);

  @override
  _MedicationPageState createState() => _MedicationPageState();
}

class _MedicationPageState extends State<MedicationPage> {
  String? _selectedOption;
  String? _medicationName;
  final MedicationController _controller = MedicationController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Médicaments et Lithiase'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Lithiase induite par médicament :',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10.0),
              RadioListTile<String>(
                title: const Text('Oui'),
                value: 'oui',
                groupValue: _selectedOption,
                onChanged: (value) {
                  setState(() {
                    _selectedOption = value;
                  });
                },
              ),
              RadioListTile<String>(
                title: const Text('Non'),
                value: 'non',
                groupValue: _selectedOption,
                onChanged: (value) {
                  setState(() {
                    _selectedOption = value;
                  });
                },
              ),
              if (_selectedOption == 'oui') ...[
                const SizedBox(height: 20.0),
                TextFormField(
                  decoration: const InputDecoration(
                    labelText: 'Préciser le médicament',
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (value) {
                    setState(() {
                      _medicationName = value;
                    });
                  },
                ),
              ],
              const SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: _saveDataAndNavigate,
                child: const Text('Submit'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _saveDataAndNavigate() async {
    if (_selectedOption == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Veuillez sélectionner une option')),
      );
      return;
    }

    Medication medication = Medication(
      selectedOption: _selectedOption,
      medicationName: _medicationName,
    );

    await _controller.saveMedication(widget.patientId, medication, context);

    Navigator.pushNamed(
      context,
      '/calcul',
      arguments: widget.patientId,
    );
  }
}
