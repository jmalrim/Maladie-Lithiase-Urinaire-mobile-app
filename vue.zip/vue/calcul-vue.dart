import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:fatouma/controlleurs/calcul-controller.dart';
import 'package:fatouma/modéle/calcul-model.dart';

class CalculPage extends StatefulWidget {
  final String patientId;

  const CalculPage({Key? key, required this.patientId}) : super(key: key);

  @override
  _CalculPageState createState() => _CalculPageState();
}

class _CalculPageState extends State<CalculPage> {
  String? _radioSelection;
  String? taille;
  String? localisation;
  String? lateralite;
  String? caracteristiques;
  String? modeEvacuation;
  XFile? _image;
  final CalculController _controller = CalculController();

  Future<void> _pickImage() async {
    try {
      final picker = ImagePicker();
      final pickedFile = await picker.pickImage(source: ImageSource.gallery);

      setState(() {
        _image = pickedFile;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to pick image: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Calcul'),
        ),
        body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
    child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Text('Y a-t-il des calculs ?'),
      ListTile(
        title: const Text('Oui'),
        leading: Radio<String>(
          value: 'Oui',
          groupValue: _radioSelection,
          onChanged: (String? value) {
            setState(() {
              _radioSelection = value;
            });
          },
        ),
      ),
      ListTile(
        title: const Text('Non'),
        leading: Radio<String>(
          value: 'Non',
          groupValue: _radioSelection,
          onChanged: (String? value) {
            setState(() {
              _radioSelection = value;
            });
          },
        ),
      ),

      if (_radioSelection == 'Oui') ...[
        const SizedBox(height: 20),
        const Text('Taille :'),
        _buildRadioOption('taille', '< 5 mm', 'taille'),
        _buildRadioOption('taille', '5-10 mm', 'taille'),
        _buildRadioOption('taille', '10-20 mm', 'taille'),
        _buildRadioOption('taille', '> 20 mm', 'taille'),
        const SizedBox(height: 20),
        const Text('Localisation :'),
        _buildRadioOption('localisation', 'CS', 'localisation'),
        _buildRadioOption('localisation', 'CM', 'localisation'),
        _buildRadioOption('localisation', 'CI', 'localisation'),
        _buildRadioOption('localisation', 'Pyélon', 'localisation'),
        _buildRadioOption('localisation', 'U.P.', 'localisation'),
        _buildRadioOption('localisation', 'U.L.', 'localisation'),
        _buildRadioOption('localisation', 'Vessie', 'localisation'),
        const SizedBox(height: 20),
        const Text('Latéralité :'),
        _buildRadioOption('lateralite', 'Droit', 'lateralite'),
        _buildRadioOption('lateralite', 'Gauche', 'lateralite'),
        const SizedBox(height: 20),
        const Text('Caractéristiques à l\'AUSP :'),
        _buildRadioOption('caracteristiques', 'Radio-opaque', 'caracteristiques'),
        _buildRadioOption('caracteristiques', 'Faiblement radio-opaque', 'caracteristiques'),
        _buildRadioOption('caracteristiques', 'Radio-transparent', 'caracteristiques'),
        const SizedBox(height: 20),
        const Text('Mode d\'évacuation du calcul :'),
        _buildRadioOption('modeEvacuation', 'Spontanée', 'modeEvacuation'),
        _buildRadioOption('modeEvacuation', 'Urétéroscopie', 'modeEvacuation'),
        _buildRadioOption('modeEvacuation', 'Néphrolithotomie percutanée', 'modeEvacuation'),
        _buildRadioOption('modeEvacuation', 'Chirurgie à ciel ouvert', 'modeEvacuation'),
        _buildRadioOption('modeEvacuation', 'Coelio-chirurgie', 'modeEvacuation'),
        const SizedBox(height: 20),
        const Text('Télécharger l\'image du calcul :'),
        GestureDetector(
          onTap: _pickImage,
          child: Container(
            width: double.infinity,
            height: 200,
            color: Colors.grey[300],
            child: _image == null
                ? const Icon(Icons.add, size: 50)
                : Image.file(File(_image!.path)),
          ),
        ),
      ],
      const SizedBox(height: 20),
      ElevatedButton(
        onPressed: _saveCalcul,
        child: const Text('Ajouter un calcul'),
      ),
    ],
    ),
        ),
    );
  }

  Widget _buildRadioOption(String group, String value, String type) {
    return ListTile(
      title: Text(value),
      leading: Radio<String>(
        value: value,
        groupValue: _getSelectedValue(type),
        onChanged: (newValue) {
          setState(() {
            _setSelectedValue(type, newValue);
          });
        },
      ),
    );
  }

  String? _getSelectedValue(String type) {
    switch (type) {
      case 'taille':
        return taille;
      case 'localisation':
        return localisation;
      case 'lateralite':
        return lateralite;
      case 'caracteristiques':
        return caracteristiques;
      case 'modeEvacuation':
        return modeEvacuation;
      default:
        return null;
    }
  }

  void _setSelectedValue(String type, String? value) {
    switch (type) {
      case 'taille':
        taille = value;
        break;
      case 'localisation':
        localisation = value;
        break;
      case 'lateralite':
        lateralite = value;
        break;
      case 'caracteristiques':
        caracteristiques = value;
        break;
      case 'modeEvacuation':
        modeEvacuation = value;
        break;
    }
  }

  void _saveCalcul() async {
    if (_radioSelection != 'Oui') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select "Oui" to add a calcul')),
      );
      return;
    }

    Calcul calcul = Calcul(
      taille: taille,
      localisation: localisation,
      lateralite: lateralite,
      caracteristiques: caracteristiques,
      modeEvacuation: modeEvacuation,
    );

    await _controller.saveCalcul(widget.patientId, calcul, _image != null ? File(_image!.path) : null, context);

    Navigator.pushNamed(
      context,
      '/drainage',
      arguments: widget.patientId,
    );
  }
}

