import 'package:fatouma/controlleurs/signup-controller.dart';
import 'package:flutter/material.dart';
import 'package:fatouma/widgets/custom_scaffold.dart';
import 'package:fatouma/vue/signin-view.dart';
import 'package:fatouma/vue/signup-view.dart';
import 'package:fatouma/widgets/welcome_button.dart';
import 'package:fatouma/controlleurs/signin-controller.dart';

class Welcome extends StatelessWidget {
  const Welcome({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 40.0, horizontal: 40.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              const Text(
                '\nLithoApp',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.blue,
                  fontSize: 60.0,
                  fontWeight: FontWeight.w400,
                ),
              ),
              const SizedBox(height: 40),

              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: 80.0),
                  WelcomeButton(
                    buttonText: 'Sign In',
                    onTap: () {
                      // Utilizing the controller to manage sign-in
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SignInView(controller: SignInController())),
                      );
                    },
                    color: Colors.blue,
                    textColor: Colors.white,
                  ),
                  const SizedBox(height: 10.0), // Add space between the buttons
                  WelcomeButton(
                    buttonText: 'Sign Up',
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => SignUpScreen(controller: SignUpController())),
                    ),
                    color: Colors.blue,
                    textColor: Colors.white,
                  ),
                  const SizedBox(height: 50.0), // Add space between the buttons
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
