// vues/anatomical_anomalies-vue.dart

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fatouma/controlleurs/anatomical-anomalies-controller.dart';
import 'package:fatouma/modéle/anatomical-anomalies-model.dart';


class AnatomicalAnomaliesPage extends StatefulWidget {
  final String patientId;

  const AnatomicalAnomaliesPage({Key? key, required this.patientId}) : super(key: key);

  @override
  _AnatomicalAnomaliesPageState createState() => _AnatomicalAnomaliesPageState();
}

class _AnatomicalAnomaliesPageState extends State<AnatomicalAnomaliesPage> {
  String? _selectedAnomaly;
  String? _radioSelection;
  String? _otherAnomaly;
  final AnatomicalAnomaliesController _controller = AnatomicalAnomaliesController();
  final List<String> _anomalyOptions = [
    'Ectasie tubulaire',
    'Anomalies de la jonction pyélourétérale',
    'Diverticule ou kyste caliciel',
    'Sténose urétérale',
    'Reflux vésico-urétéral',
    'Rien en fer à cheval',
    'Urétérocèle',
  ];

  void _saveAnomaly() async {
    if (_radioSelection == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Veuillez sélectionner une option')),
      );
      return;
    }

    String anomalyToSave = _radioSelection == 'Autre' ? _otherAnomaly ?? '' : _selectedAnomaly ?? '';

    AnatomicalAnomaly anomaly = AnatomicalAnomaly(
      selectedAnomaly: anomalyToSave,
    );

    await _controller.saveAnatomicalAnomaly(widget.patientId, anomaly, context);

    Navigator.pushNamed(
      context,
      '/associated_diseases',
      arguments: widget.patientId,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Anomalies Anatomiques'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ListTile(
              title: const Text('Oui'),
              leading: Radio<String>(
                value: 'Oui',
                groupValue: _radioSelection,
                onChanged: (String? value) {
                  setState(() {
                    _radioSelection = value;
                  });
                },
              ),
            ),
            ListTile(
              title: const Text('Non'),
              leading: Radio<String>(
                value: 'Non',
                groupValue: _radioSelection,
                onChanged: (String? value) {
                  setState(() {
                    _radioSelection = value;
                  });
                },
              ),
            ),
            ListTile(
              title: const Text('Autre'),
              leading: Radio<String>(
                value: 'Autre',
                groupValue: _radioSelection,
                onChanged: (String? value) {
                  setState(() {
                    _radioSelection = value;
                  });
                },
              ),
            ),
            if (_radioSelection == 'Oui') ...[
              DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  labelText: 'Sélectionner une anomalie',
                  border: OutlineInputBorder(),
                ),
                value: _selectedAnomaly,
                items: _anomalyOptions.map((anomaly) {
                  return DropdownMenuItem<String>(
                    value: anomaly,
                    child: Text(anomaly),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedAnomaly = value;
                  });
                },
              ),
              SizedBox(height: 20.0),
            ] else if (_radioSelection == 'Autre') ...[
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'Veuillez préciser',
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) {
                  setState(() {
                    _otherAnomaly = value;
                  });
                },
              ),
              SizedBox(height: 20.0),
            ],
            ElevatedButton(
              onPressed: _saveAnomaly,
              child: Text('Enregistrer l\'anomalie'),
            ),
          ],
        ),
      ),
    );
  }
}
