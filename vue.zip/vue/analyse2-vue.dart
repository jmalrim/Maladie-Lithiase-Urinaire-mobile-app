import 'package:flutter/material.dart';
import 'package:fatouma/controlleurs/analyse2-controller.dart';
import 'package:fatouma/modéle/analyse2-model.dart';

class Analyse2Page extends StatefulWidget {
  final String patientId;

  const Analyse2Page({Key? key, required this.patientId}) : super(key: key);

  @override
  _Analyse2PageState createState() => _Analyse2PageState();
}

class _Analyse2PageState extends State<Analyse2Page> {
  final Analyse2Controller _controller = Analyse2Controller();
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _tailleController = TextEditingController();
  final TextEditingController _surfaceController = TextEditingController();
  final TextEditingController _couleurController = TextEditingController();
  final TextEditingController _sectionController = TextEditingController();
  final TextEditingController _couchesExternesController = TextEditingController();
  final TextEditingController _noyauController = TextEditingController();
  final TextEditingController _surfaceInfrarougeController = TextEditingController();
  final TextEditingController _sectionInfrarougeController = TextEditingController();
  final TextEditingController _couchesExternesInfrarougeController = TextEditingController();
  final TextEditingController _noyauInfrarougeController = TextEditingController();
  final TextEditingController _typeCalculController = TextEditingController();

  @override
  void dispose() {
    _tailleController.dispose();
    _surfaceController.dispose();
    _couleurController.dispose();
    _sectionController.dispose();
    _couchesExternesController.dispose();
    _noyauController.dispose();
    _surfaceInfrarougeController.dispose();
    _sectionInfrarougeController.dispose();
    _couchesExternesInfrarougeController.dispose();
    _noyauInfrarougeController.dispose();
    _typeCalculController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Analyse du calcul')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Veuillez entrer les données de l\'analyse du calcul :',
                  style: TextStyle(fontSize: 18),
                ),
                const SizedBox(height: 10),
                const Text('Analyse morphologique :'),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _tailleController,
                  decoration: const InputDecoration(labelText: 'Taille'),
                  validator: (value) => value == null || value.isEmpty ? 'Champ obligatoire' : null,
                ),
                TextFormField(
                  controller: _surfaceController,
                  decoration: const InputDecoration(labelText: 'Surface'),
                  validator: (value) => value == null || value.isEmpty ? 'Champ obligatoire' : null,
                ),
                TextFormField(
                  controller: _couleurController,
                  decoration: const InputDecoration(labelText: 'Couleur'),
                  validator: (value) => value == null || value.isEmpty ? 'Champ obligatoire' : null,
                ),
                TextFormField(
                  controller: _sectionController,
                  decoration: const InputDecoration(labelText: 'Section'),
                  validator: (value) => value == null || value.isEmpty ? 'Champ obligatoire' : null,
                ),
                TextFormField(
                  controller: _couchesExternesController,
                  decoration: const InputDecoration(labelText: 'Couches externes'),
                  validator: (value) => value == null || value.isEmpty ? 'Champ obligatoire' : null,
                ),
                TextFormField(
                  controller: _noyauController,
                  decoration: const InputDecoration(labelText: 'Noyau'),
                  validator: (value) => value == null || value.isEmpty ? 'Champ obligatoire' : null,
                ),
                const SizedBox(height: 20),
                const Text('Spectrophotométrie infrarouge :'),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _surfaceInfrarougeController,
                  decoration: const InputDecoration(labelText: 'Surface'),
                  validator: (value) => value == null || value.isEmpty ? 'Champ obligatoire' : null,
                ),
                TextFormField(
                  controller: _sectionInfrarougeController,
                  decoration: const InputDecoration(labelText: 'Section'),
                  validator: (value) => value == null || value.isEmpty ? 'Champ obligatoire' : null,
                ),
                TextFormField(
                  controller: _couchesExternesInfrarougeController,
                  decoration: const InputDecoration(labelText: 'Couches externes'),
                  validator: (value) => value == null || value.isEmpty ? 'Champ obligatoire' : null,
                ),
                TextFormField(
                  controller: _noyauInfrarougeController,
                  decoration: const InputDecoration(labelText: 'Noyau'),
                  validator: (value) => value == null || value.isEmpty ? 'Champ obligatoire' : null,
                ),
                TextFormField(
                  controller: _typeCalculController,
                  decoration: const InputDecoration(labelText: 'Type du calcul'),
                  validator: (value) => value == null || value.isEmpty ? 'Champ obligatoire' : null,
                ),
                const SizedBox(height: 20),
                Center(
                  child: ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        print('All fields are valid. Creating Analyse2 object...');
                        Analyse2 analyse2 = Analyse2(
                          taille: _tailleController.text.isNotEmpty ? _tailleController.text : '',
                          surface: _surfaceController.text.isNotEmpty ? _surfaceController.text : '',
                          couleur: _couleurController.text.isNotEmpty ? _couleurController.text : '',
                          section: _sectionController.text.isNotEmpty ? _sectionController.text : '',
                          couchesExternes: _couchesExternesController.text.isNotEmpty ? _couchesExternesController.text : '',
                          noyau: _noyauController.text.isNotEmpty ? _noyauController.text : '',
                          surfaceInfrarouge: _surfaceInfrarougeController.text.isNotEmpty ? _surfaceInfrarougeController.text : '',
                          sectionInfrarouge: _sectionInfrarougeController.text.isNotEmpty ? _sectionInfrarougeController.text : '',
                          couchesExternesInfrarouge: _couchesExternesInfrarougeController.text.isNotEmpty ? _couchesExternesInfrarougeController.text : '',
                          noyauInfrarouge: _noyauInfrarougeController.text.isNotEmpty ? _noyauInfrarougeController.text : '',
                          typeCalcul: _typeCalculController.text.isNotEmpty ? _typeCalculController.text : '',
                        );
                        print('Analyse2 object created: ${analyse2.toMap()}');
                        _controller.saveAnalyse2Data(widget.patientId, analyse2).then((_) {
                          Navigator.pushNamed(
                            context,
                            '/patientdetail',
                            arguments: widget.patientId,
                          );
                        });
                      } else {
                        print('Some fields are invalid.');
                      }
                    },
                    child: const Text('Valider'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
