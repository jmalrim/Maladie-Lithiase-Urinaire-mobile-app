

import 'package:flutter/material.dart';
import 'package:fatouma/controlleurs/new-patient-controller.dart';
import 'package:fatouma/modéle/new-patient-model.dart';


class NewPatientPage extends StatelessWidget {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  NewPatientPage({super.key});

  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _dayController = TextEditingController();
  final TextEditingController _monthController = TextEditingController();
  final TextEditingController _yearController = TextEditingController();
  final TextEditingController _genderController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _recordNumberController = TextEditingController();

  final NewPatientController _controller = NewPatientController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: const Text('Nouveau Patient'),
        automaticallyImplyLeading: false,
        leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () {
            _scaffoldKey.currentState?.openDrawer();
          },
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text(
                'Menu',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.local_hospital),
              title: const Text('Facteurs Généraux'),
              onTap: () {
                Navigator.pushNamed(context, '/general_factors', arguments: '');
              },
            ),
            ListTile(
              leading: const Icon(Icons.healing),
              title: const Text('Maladies Associées'),
              onTap: () {
                Navigator.pushNamed(context, '/associated_diseases', arguments: '');
              },
            ),
            ListTile(
              leading: const Icon(Icons.biotech),
              title: const Text('Maladies Génétiques'),
              onTap: () {
                Navigator.pushNamed(context, '/genetic_diseases', arguments: '');
              },
            ),
            ListTile(
              leading: const Icon(Icons.medication),
              title: const Text('Médicaments'),
              onTap: () {
                Navigator.pushNamed(context, '/medications', arguments: '');
              },
            ),
            ListTile(
              leading: const Icon(Icons.health_and_safety),
              title: const Text('Anomalies Anatomiques'),
              onTap: () {
                Navigator.pushNamed(context, '/anatomical_anomalies', arguments: '');
              },
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildNameField(),
              const SizedBox(height: 20.0),
              _buildDateOfBirthField(),
              const SizedBox(height: 20.0),
              _buildGenderField(),
              const SizedBox(height: 20.0),
              _buildHeightWeightFields(),
              const SizedBox(height: 20.0),
              _buildAddressField(),
              const SizedBox(height: 20.0),
              _buildEmailField(),
              const SizedBox(height: 20.0),
              _buildPhoneField(),
              const SizedBox(height: 20.0),
              _buildRecordNumberField(),
              const SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: () => _createPatientRecord(context),
                child: const Text('Créer le Dossier'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _createPatientRecord(BuildContext context) async {
    if (_formKey.currentState!.validate()) {
      Patient newPatient = Patient(
        name: _nameController.text,
        dateOfBirth: DateTime(
          int.tryParse(_yearController.text) ?? 0,
          int.tryParse(_monthController.text) ?? 0,
          int.tryParse(_dayController.text) ?? 0,
        ),
        gender: _genderController.text,
        height: double.tryParse(_heightController.text) ?? 0.0,
        weight: double.tryParse(_weightController.text) ?? 0.0,
        address: _addressController.text,
        email: _emailController.text,
        phone: _phoneController.text,
        recordNumber: _recordNumberController.text,
      );

      await _controller.createPatient(newPatient, context);
    }
  }

  Widget _buildNameField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Nom et Prénom',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10.0),
        TextFormField(
          controller: _nameController,
          decoration: const InputDecoration(
            hintText: 'Entrez votre nom et prénom',
            border: OutlineInputBorder(),
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Veuillez entrer votre nom et prénom';
            }
            return null;
          },
        ),
      ],
    );
  }

  Widget _buildDateOfBirthField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Date de Naissance',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10.0),
        Row(
          children: [
            Expanded(
              child: TextFormField(
                controller: _dayController,
                decoration: const InputDecoration(
                    hintText: 'Jour', border: OutlineInputBorder()),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Veuillez entrer le jour';
                  }
                  return null;
                },
              ),
            ),
            const SizedBox(width: 10.0),
            Expanded(
              child: TextFormField(
                controller: _monthController,
                decoration: const InputDecoration(
                    hintText: 'Mois', border: OutlineInputBorder()),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Veuillez entrer le mois';
                  }
                  return null;
                },
              ),
            ),
            const SizedBox(width: 10.0),
            Expanded(
              child: TextFormField(
                controller: _yearController,
                decoration: const InputDecoration(
                    hintText: 'Année', border: OutlineInputBorder()),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Veuillez entrer l\'année';
                  }
                  return null;
                },
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildGenderField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Sexe',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10.0),
        TextFormField(
          controller: _genderController,
          decoration: const InputDecoration(
            hintText: 'Entrez votre sexe',
            border: OutlineInputBorder(),
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Veuillez entrer votre sexe';
            }
            return null;
          },
        ),
      ],
    );
  }

  Widget _buildHeightWeightFields() {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Taille (cm)',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10.0),
              TextFormField(
                controller: _heightController,
                decoration: const InputDecoration(
                  hintText: 'Entrez votre taille',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Veuillez entrer votre taille';
                  }
                  return null;
                },
              ),
            ],
          ),
        ),
        const SizedBox(width: 10.0),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Poids (kg)',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10.0),
              TextFormField(
                controller: _weightController,
                decoration: const InputDecoration(
                  hintText: 'Entrez votre poids',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Veuillez entrer votre poids';
                  }
                  return null;
                },
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildAddressField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Adresse',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10.0),
        TextFormField(
          controller: _addressController,
          decoration: const InputDecoration(
            hintText: 'Entrez votre adresse',
            border: OutlineInputBorder(),
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Veuillez entrer votre adresse';
            }
            return null;
          },
        ),
      ],
    );
  }

  Widget _buildEmailField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Email',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10.0),
        TextFormField(
          controller: _emailController,
          decoration: const InputDecoration(
            hintText: 'Entrez votre email',
            border: OutlineInputBorder(),
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Veuillez entrer votre email';
            }
            return null;
          },
        ),
      ],
    );
  }

  Widget _buildPhoneField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Téléphone',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10.0),
        TextFormField(
          controller: _phoneController,
          decoration: const InputDecoration(
            hintText: 'Entrez votre téléphone',
            border: OutlineInputBorder(),
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Veuillez entrer votre téléphone';
            }
            return null;
          },
        ),
      ],
    );
  }

  Widget _buildRecordNumberField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Numéro de Dossier',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10.0),
        TextFormField(
          controller: _recordNumberController,
          decoration: const InputDecoration(
            hintText: 'Entrez votre numéro de dossier',
            border: OutlineInputBorder(),
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Veuillez entrer votre numéro de dossier';
            }
            return null;
          },
        ),
      ],
    );
  }
}
