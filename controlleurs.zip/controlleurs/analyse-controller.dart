import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fatouma/modéle/analyse-model.dart';

class AnalyseController {
  final DatabaseReference _database = FirebaseDatabase.instance.reference();

  Future<Patient?> fetchPatientData(String patientId) async {
    try {
      User? user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        print('No user currently signed in.');
        return null;
      }

      print('Fetching patient data for patientId: $patientId');

      // Fetch all doctors
      DataSnapshot doctorsSnapshot = await _database.child('doctors').get();
      if (doctorsSnapshot.exists && doctorsSnapshot.value != null) {
        Map<dynamic, dynamic> doctorsMap = doctorsSnapshot.value as Map<dynamic, dynamic>;

        for (var doctorEntry in doctorsMap.entries) {
          String doctorId = doctorEntry.key;
          print('Checking doctor ID: $doctorId');

          // Fetch patients of the doctor
          DataSnapshot patientsSnapshot = await _database.child('doctors/$doctorId/patients').get();
          if (patientsSnapshot.exists && patientsSnapshot.value != null) {
            Map<dynamic, dynamic> patientsMap = patientsSnapshot.value as Map<dynamic, dynamic>;

            if (patientsMap.containsKey(patientId)) {
              print('Found patient with ID: $patientId under doctor ID: $doctorId');
              Map<String, dynamic> patientData = Map<String, dynamic>.from(patientsMap[patientId]);

              // Fetch calculs data
              DataSnapshot calculsSnapshot = await _database.child('doctors/$doctorId/patients/$patientId/calculs').get();
              if (calculsSnapshot.exists && calculsSnapshot.value != null) {
                Map<dynamic, dynamic> calculsMap = calculsSnapshot.value as Map<dynamic, dynamic>;
                String? imageUrl;

                for (var calcul in calculsMap.values) {
                  if (calcul.containsKey('imageUrl')) {
                    imageUrl = calcul['imageUrl'];
                    break;
                  }
                }

                return Patient.fromMap(patientData, imageUrl);
              }
            }
          }
        }
      }

      print('No snapshot data available for patientId: $patientId');
    } catch (e) {
      print('Error fetching patient data: $e');
    }
    return null;
  }
}
