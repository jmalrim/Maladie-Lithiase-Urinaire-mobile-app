import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';


class HomeController {
  final DatabaseReference _database = FirebaseDatabase.instance.reference();
  final User? user = FirebaseAuth.instance.currentUser;

  Future<String> getFullName() async {
    if (user == null) return 'Unknown';
    DataSnapshot snapshot = await _database.child('doctors/${user!.uid}/fullName').get();
    return snapshot.value as String? ?? 'Unknown2';
  }

  Future<String> getProfession() async {
    if (user == null) return 'Unknown';
    DataSnapshot snapshot = await _database.child('doctors/${user!.uid}/profession').get();
    return snapshot.value as String? ?? 'Unknown2';
  }

  void handleMenuAction(String value, BuildContext context) {
    switch (value) {
      case 'patient_list':
        Navigator.pushNamed(
            context,
            '/biochemist-patients-list'
        );
        break;
    }
  }
}
