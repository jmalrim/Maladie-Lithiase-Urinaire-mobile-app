
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fatouma/modéle/genetic-desease-model.dart';

class GeneticDiseasesController {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final DatabaseReference _database = FirebaseDatabase.instance.reference();

  Future<void> saveGeneticDisease(String patientId, GeneticDisease geneticDisease, BuildContext context) async {
    User? user = _auth.currentUser;
    if (user != null) {
      String uid = user.uid;
      DatabaseReference geneticDiseasesRef = _database.child('doctors/$uid/patients/$patientId/geneticDiseases');

      await geneticDiseasesRef.set(geneticDisease.toJson());

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Data saved successfully')),
      );
    }
  }
}
