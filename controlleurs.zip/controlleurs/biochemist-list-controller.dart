import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fatouma/modéle/biochemist-list-model.dart';

class BiochemistPatientsController {
  final DatabaseReference _database = FirebaseDatabase.instance.reference();

  Future<List<PatientSummary>> fetchAllPatients() async {
    List<PatientSummary> allPatients = [];
    DataSnapshot doctorsSnapshot = await _database.child('doctors').get();

    print('Doctors Snapshot: ${doctorsSnapshot.value}'); // Debug print

    if (doctorsSnapshot.exists && doctorsSnapshot.value != null) {
      Map<dynamic, dynamic> doctorsMap = doctorsSnapshot.value as Map<dynamic, dynamic>;
      for (var doctorKey in doctorsMap.keys) {
        print('Fetching patients for doctor: $doctorKey'); // Debug print
        DataSnapshot patientsSnapshot = await _database.child('doctors/$doctorKey/patients').get();
        print('Patients Snapshot for $doctorKey: ${patientsSnapshot.value}'); // Debug print

        if (patientsSnapshot.exists && patientsSnapshot.value != null) {
          Map<dynamic, dynamic> patientsMap = patientsSnapshot.value as Map<dynamic, dynamic>;
          patientsMap.forEach((key, value) {
            print('Patient Key: $key, Value: $value'); // Debug print
            allPatients.add(PatientSummary.fromMap(key, Map<String, dynamic>.from(value)));
          });
        }
      }
    }

    print('All Patients: $allPatients'); // Debug print
    return allPatients;
  }
}
