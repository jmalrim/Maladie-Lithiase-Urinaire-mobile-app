import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:fatouma/modéle/calcul-model.dart';
import 'dart:io';

class CalculController {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final DatabaseReference _database = FirebaseDatabase.instance.reference();
  final FirebaseStorage _storage = FirebaseStorage.instance;

  Future<void> saveCalcul(String patientId, Calcul calcul, File? image, BuildContext context) async {
    try {
      User? user = _auth.currentUser;
      if (user != null) {
        String uid = user.uid;
        DatabaseReference calculRef = _database.child('doctors/$uid/patients/$patientId/calculs').push();

        if (image != null) {
          String fileName = DateTime.now().millisecondsSinceEpoch.toString();
          Reference storageRef = _storage.ref().child('calcul_images').child(fileName);
          UploadTask uploadTask = storageRef.putFile(image);

          TaskSnapshot snapshot = await uploadTask;
          String downloadUrl = await snapshot.ref.getDownloadURL();
          calcul.imageUrl = downloadUrl;
        }
        await calculRef.set(calcul.toJson());

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Calcul saved successfully!')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to save calcul: $e')),
      );
    }
  }
}
