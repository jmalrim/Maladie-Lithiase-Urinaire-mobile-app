// controlleurs/drainage-controller.dart

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fatouma/modéle/drainage-model.dart';

class DrainageController {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final DatabaseReference _database = FirebaseDatabase.instance.reference();

  Future<void> saveDrainage(String patientId, Drainage drainage, BuildContext context) async {
    User? user = _auth.currentUser;
    if (user != null) {
      String uid = user.uid;
      DatabaseReference drainageRef = _database.child('doctors/$uid/patients/$patientId/drainages').push();

      await drainageRef.set(drainage.toJson());

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Drainage saved successfully!')),
      );
    }
  }
}
