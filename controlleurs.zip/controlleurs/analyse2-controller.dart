import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fatouma/modéle/analyse2-model.dart';

class Analyse2Controller {
  final DatabaseReference _database = FirebaseDatabase.instance.reference();

  Future<void> saveAnalyse2Data(String patientId, Analyse2 analyse2) async {
    try {
      User? user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        print('No user currently signed in.');
        return;
      }

      // Fetch all doctors to find the patient
      DataSnapshot doctorsSnapshot = await _database.child('doctors').get();
      if (doctorsSnapshot.exists && doctorsSnapshot.value != null) {
        Map<dynamic, dynamic> doctorsMap = doctorsSnapshot.value as Map<dynamic, dynamic>;

        for (var doctorEntry in doctorsMap.entries) {
          String doctorId = doctorEntry.key;
          print('Checking doctor ID: $doctorId');

          // Fetch patients of the doctor
          DataSnapshot patientsSnapshot = await _database.child('doctors/$doctorId/patients').get();
          if (patientsSnapshot.exists && patientsSnapshot.value != null) {
            Map<dynamic, dynamic> patientsMap = patientsSnapshot.value as Map<dynamic, dynamic>;

            if (patientsMap.containsKey(patientId)) {
              print('Found patient with ID: $patientId under doctor ID: $doctorId');
              await _database.child('doctors/$doctorId/patients/$patientId/analyse2').set(analyse2.toMap());
              print('Analyse2 data saved successfully.');
              return;
            }
          }
        }
      }

      print('No patient found with ID: $patientId');
    } catch (e) {
      print('Error saving analyse2 data: $e');
    }
  }
}
