// controllers/new_patient_controller.dart

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fatouma/modéle/new-patient-model.dart';

import '../vue/anatomical-anomalies-vue.dart';

class NewPatientController {
  final DatabaseReference _database = FirebaseDatabase.instance.reference();
  final User? user = FirebaseAuth.instance.currentUser;

  Future<void> createPatient(Patient patient, BuildContext context) async {
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Erreur: Utilisateur non connecté')),
      );
      return;
    }

    try {
      DatabaseReference patientsRef = _database.child('doctors').child(user!.uid).child('patients');

      DatabaseReference newPatientRef = patientsRef.push();
      await newPatientRef.set(patient.toJson());

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Dossier créé avec succès')),
      );

      // Navigate to AnatomicalAnomaliesPage with the new patient ID
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => AnatomicalAnomaliesPage(patientId: newPatientRef.key!),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erreur: $e')),
      );
    }
  }
}
