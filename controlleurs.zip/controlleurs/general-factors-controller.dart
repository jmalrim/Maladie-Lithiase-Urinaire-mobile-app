// controlleurs/general_factors-controller.dart

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fatouma/modéle/general-factors-model.dart';

class GeneralFactorsController {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final DatabaseReference _database = FirebaseDatabase.instance.reference();

  Future<void> saveGeneralFactors(String patientId, GeneralFactors generalFactors, BuildContext context) async {
    User? user = _auth.currentUser;
    if (user != null) {
      String uid = user.uid;
      DatabaseReference generalFactorsRef = _database.child('doctors/$uid/patients/$patientId/generalFactors');

      await generalFactorsRef.set(generalFactors.toJson());

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Data saved successfully')),
      );
    }
  }
}
