import 'package:firebase_database/firebase_database.dart';
import 'package:fatouma/modéle/patient-detail-model.dart';

class PatientDetailController {
  final DatabaseReference _database = FirebaseDatabase.instance.reference();

  Future<Patient?> fetchPatientData(String patientId) async {
    try {
      // Fetch all doctors
      DataSnapshot doctorsSnapshot = await _database.child('doctors').get();
      if (doctorsSnapshot.exists) {
        Map<dynamic, dynamic> doctorsMap = doctorsSnapshot.value as Map<dynamic, dynamic>;

        // Iterate through each doctor to find the patient
        for (var doctorKey in doctorsMap.keys) {
          DataSnapshot patientSnapshot = await _database.child('doctors/$doctorKey/patients/$patientId').get();
          if (patientSnapshot.exists) {
            print('Snapshot value for patient $patientId: ${patientSnapshot.value}'); // Debugging line
            Map<String, dynamic> patientData = (patientSnapshot.value as Map<dynamic, dynamic>).cast<String, dynamic>();

            // Ensure nested maps are properly cast
            if (patientData['calculs'] != null && patientData['calculs'] is Map) {
              patientData['calculs'] = (patientData['calculs'] as Map<dynamic, dynamic>).map<String, Map<String, dynamic>>(
                      (key, value) => MapEntry(key as String, (value as Map<dynamic, dynamic>).cast<String, dynamic>())
              );
            }

            if (patientData['drainages'] != null && patientData['drainages'] is Map) {
              patientData['drainages'] = (patientData['drainages'] as Map<dynamic, dynamic>).map<String, Map<String, dynamic>>(
                      (key, value) => MapEntry(key as String, (value as Map<dynamic, dynamic>).cast<String, dynamic>())
              );
            }

            return Patient.fromMap(patientData);
          }
        }
        print('Patient $patientId not found under any doctor'); // Debugging line
      } else {
        print('No doctors found'); // Debugging line
      }
    } catch (e) {
      print('Error fetching patient data: $e'); // Debugging line
    }

    return null;
  }
}
