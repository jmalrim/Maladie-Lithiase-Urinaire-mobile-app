// controlleurs/associated_diseases-controller.dart

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fatouma/modéle/associated-diseases-model.dart';

class AssociatedDiseasesController {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final DatabaseReference _database = FirebaseDatabase.instance.reference();

  Future<void> saveAssociatedDiseases(String patientId, AssociatedDiseases diseases, BuildContext context) async {
    User? user = _auth.currentUser;
    if (user != null) {
      String uid = user.uid;
      DatabaseReference diseasesRef = _database.child('doctors/$uid/patients/$patientId/associatedDiseases');

      await diseasesRef.set(diseases.toJson());

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Data saved successfully')),
      );
    }
  }
}
