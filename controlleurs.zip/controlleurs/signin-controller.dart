import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:fatouma/modéle/user-model.dart';

class SignInController {
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  final DatabaseReference _database = FirebaseDatabase.instance.reference();
  UserModel? _userModel;

  void updateEmail(String email) {
    if (_userModel == null) {
      _userModel = UserModel(email: email, password: '');
    } else {
      _userModel!.email = email;
    }
  }

  void updatePassword(String password) {
    if (_userModel == null) {
      _userModel = UserModel(email: '', password: password);
    } else {
      _userModel!.password = password;
    }
  }

  Future<void> signIn(BuildContext context, String email, String password) async {
    try {
      UserCredential userCredential = await _firebaseAuth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      if (userCredential.user != null) {
        User? user = _firebaseAuth.currentUser;
        if (user != null) {
          DatabaseReference userRef = _database.child('doctors/${user.uid}');
          DataSnapshot snapshot = await userRef.get();

          if (snapshot.exists) {
            Map<String, dynamic> userData = Map<String, dynamic>.from(snapshot.value as Map);
            String profession = userData['profession'];

            if (profession == 'Biochimiste') {
              Navigator.pushReplacementNamed(context, '/biochemist-home');
            } else {
              Navigator.pushReplacementNamed(context, '/home');
            }
          }
        }
      }
    } on FirebaseAuthException catch (e) {
      String errorMessage = 'An error occurred during sign in.';
      if (e.code == 'user-not-found') {
        errorMessage = 'No user found for that email.';
      } else if (e.code == 'wrong-password') {
        errorMessage = 'Wrong password provided for that user.';
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(errorMessage)),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('An error occurred: ${e.toString()}')),
      );
    }
  }
}
