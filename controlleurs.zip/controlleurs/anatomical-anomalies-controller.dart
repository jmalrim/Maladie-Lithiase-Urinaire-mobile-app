// controlleurs/anatomical_anomalies-controller.dart

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fatouma/modéle/anatomical-anomalies-model.dart';

class AnatomicalAnomaliesController {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final DatabaseReference _database = FirebaseDatabase.instance.reference();

  Future<void> saveAnatomicalAnomaly(String patientId, AnatomicalAnomaly anomaly, BuildContext context) async {
    User? user = _auth.currentUser;
    if (user != null) {
      String uid = user.uid;
      DatabaseReference anomalyRef = _database.child('doctors/$uid/patients/$patientId/anatomicalAnomalies');

      await anomalyRef.set(anomaly.toJson());

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Anomaly saved successfully!')),
      );
    }
  }
}
