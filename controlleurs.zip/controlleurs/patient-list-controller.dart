import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fatouma/modéle/patient-list-model.dart';

class ListePatientsController {
  final DatabaseReference _database = FirebaseDatabase.instance.reference();

  Future<List<PatientSummary>> fetchPatients() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user == null) return [];

    DataSnapshot snapshot = await _database.child('doctors/${user.uid}/patients').get();

    if (snapshot.exists && snapshot.value != null) {
      List<PatientSummary> patients = [];
      Map<dynamic, dynamic> patientsMap = snapshot.value as Map<dynamic, dynamic>;
      patientsMap.forEach((key, value) {
        patients.add(PatientSummary.fromMap(key, Map<String, dynamic>.from(value)));
      });
      return patients;
    } else {
      return [];
    }
  }
}
